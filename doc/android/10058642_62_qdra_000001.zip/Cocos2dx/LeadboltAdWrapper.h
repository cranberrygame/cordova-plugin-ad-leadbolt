//
//  AppFireworkWrapper.h
//  HelloCpp
//
//  Created by Tech on 1/10/13.
//
//

#ifndef __LeadboltAdWrapper__
#define __LeadboltAdWrapper__

#include "cocos2d.h"

class LeadboltAdWrapper
{
public:
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
	static void loadStartAd(const char* lbAppAdId, const char* lbAudioId);
#endif

    static void loadAd(const char* lbAppAdId);
    static void loadAudioAd(const char* lbAudioId);
    static void setLocationControl(const char* loc);
    static void setLandscapeMode(const char* lm);

    static void destroyAd();
    static void pauseAd();
    static void resumeAd();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    
    static void loadStartAd(const char* lbAppAdId, const char* lbAudioId, const char* lbReEngamentId);
    static void loadReEngagement(const char* lbReEngamentId);
    static void loadAudioTrack(const char* lbAudioId, int audioTrack);
#endif
};

#endif /* defined(__LeadboltAdWrapper__) */
